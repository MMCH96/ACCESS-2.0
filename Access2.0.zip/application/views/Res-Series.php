<link  rel="stylesheet" type="text/css" href="<?php echo base_url ();?>assets/css/estilos.css">
<h2>Nueva Reservación</h2>
<p></p>


<h1>SERIES</h1>
</header>

