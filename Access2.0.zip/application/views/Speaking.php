<label style="font-size:25px ">Welcome PruebaStud</label>
<h1>SPEAKING</h1>
<div class="wrapper">
  <a href="<?php echo base_url('index.php/Principal/ResKaraoke')?>" class="btn-base btn-cta btn-1">
    <span>KARAOKE</span>
  </a>
  <a href="<?php echo base_url('index.php/Principal/ResTandem')?>" class="btn-base btn-cta btn-2">
    <span>TANDEM</span>
  </a>
  <a href="<?php echo base_url('index.php/Principal/ResCC')?>" class="btn-base btn-cta btn-3">
    <span>CONVERSATION CLUBS</span>
  </a>
  <a href="<?php echo base_url('index.php/Principal/ResSpeaking2')?>" class="btn-base btn-cta btn-4">
    <span>SPEAKING</span>
  </a>
  <a href="<?php echo base_url('index.php/Principal/StudMod')?>" class="btn-base btn-cta btn-6">
    <span>MODULES</span>
  </a>
</div>
</body>