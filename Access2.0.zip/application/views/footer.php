<footer>
	
	<div style="background-color: #87CEEB; width: 100%; margin-top: 50px;  ">
		Camacho Hernandez Miguel Mosiah 
		<p></p>
		Naranjo Torres Jose Alfredo
	</div>
</footer>

</body>
</html>