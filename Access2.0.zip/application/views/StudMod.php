<label style="font-size:25px ">Welcome PruebaStud</label>
<h1>Student Modules</h1>


<div class="wrapper">
 
  
  <a href="<?php echo base_url('index.php/Principal/Writing')?>" class="btn-base btn-cta btn-1">
    <span>WRITING</span>
  </a>
  <a href="<?php echo base_url('index.php/Principal/Listening')?>" class="btn-base btn-cta btn-2">
    <span>LISTENING</span>
  </a>
  <a href="<?php echo base_url('index.php/Principal/Reading')?>" class="btn-base btn-cta btn-3">
    <span>READING</span>
  </a>

  <a href="<?php echo base_url('index.php/Principal/Speaking')?>" class="btn-base btn-cta btn-4">
    <span>SPEAKING</span>
  </a>
  <a href="<?php echo base_url('index.php/Principal/Reservations')?>" class="btn-base btn-cta btn-5">
    <span>MY RESERVATIONS</span>
  </a>
  <a href="<?php echo base_url('index.php/Principal/LoginAlum')?>" class="btn-base btn-cta btn-6">
    <span>LOG OUT</span>
  </a>
</div>
</div>

