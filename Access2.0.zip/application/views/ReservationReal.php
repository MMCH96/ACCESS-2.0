

<h1>RESERVATION REGISTRED</h1>
<div class="wrapper">
<img src="<?php echo base_url ();?>assets/img/reserved.jpg" >

  <a href="<?php echo base_url('index.php/Principal/StudMod')?>" class="btn-base btn-cta modulos col-sm-4 col-md-4 col-lg-4 col-xl-4">
    <span>MODULES</span>
  	</a>
</div>
</div>