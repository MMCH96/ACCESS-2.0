<label style="font-size:25px ">Welcome PruebaStud</label>
<h1>LISTENING</h1>
<div class="wrapper">
  <a href="<?php echo base_url('index.php/Principal/ResCinema')?>" class="btn-base btn-cta btn-1">
    <span>CINEMA</span>
  </a>
  <a href="<?php echo base_url('index.php/Principal/ResAudioBook')?>" class="btn-base btn-cta btn-2">
    <span>AUDIOBOOK</span>
  </a>
  <a href="<?php echo base_url('index.php/Principal/ResSeries')?>" class="btn-base btn-cta btn-3">
    <span>SERIES</span>
  </a>
  <a href="<?php echo base_url('index.php/Principal/ResSpeaking')?>" class="btn-base btn-cta btn-4">
    <span>SPEAKING</span>
  </a>
  <a href="<?php echo base_url('index.php/Principal/StudMod')?>" class="btn-base btn-cta btn-6">
    <span>MODULES</span>
  </a>
</div>
</body>