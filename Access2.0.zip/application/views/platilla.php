<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>ACCESS</title>

	<link rel="stylesheet" type="text/css" href="<?php echo base_url ();?>assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url ();?>assets/css/estilosForm.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url ();?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url ();?>assets/css/css-btns-mod-alum.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url ();?>assets/css/estilo.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url ();?>assets/css/cssnav.css">
	
	<script src="<?php echo base_url ();?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url ();?>assets/js/jquery.min.js"></script>
	<script src="<?php echo base_url ();?>assets/js/popper.min.js"></script>
	<script src="<?php echo base_url ();?>assets/js/formulario.js"></script>

	</head>

<body>

<header>
	<img src="<?php echo base_url ();?>assets/img/logo.png" id="logo" >
	
</header>

</body>
<aside>
	<p></p>
</aside>

<aside id="aside2">
	<p> </p>
</aside>
</html>
</body>
</html>

