<label style="font-size:25px ">Welcome PruebaAdmin</label>
<h1>Administrator Modules</h1>
<div class="wrapper">
  <a href="<?php echo base_url('index.php/Principal/Alumnos');?>" class="btn-base btn-cta btn-1">
    <span>STUDENTS</span>
  </a>
  <a href="<?php echo base_url('index.php/Principal/Profesores');?>" class="btn-base btn-cta btn-1">
    <span>TEACHERS</span>
  </a>
  <a href="<?php echo base_url('index.php/Principal/RegistroAlum');?>" class="btn-base btn-cta btn-5">
    <span>NEW STUDENT</span>
  </a>
  <a href="<?php echo base_url('index.php/Principal/RegistroProfe');?>" class="btn-base btn-cta btn-5">
    <span>NEW TEACHER</span>
  </a>
  <a href="<?php echo base_url('index.php/Principal/index')?>" class="btn-base btn-cta btn-6">
    <span>LOG OUT</span>
  </a>
</div>
</body>