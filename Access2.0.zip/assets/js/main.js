var nombre="Migue";
var edad;
var datos=document.getElementById('dato').innerHTML=`<h1> Elementos JavaScript</h1> <h2> Mi nombre es ${nombre}</h2>`;

if(nombre=="Miguel")
{
	document.bgColor="blue";
	document.title="Hola";
}else{
	document.bgColor="tomato";
	document.title="HOLA";
}


